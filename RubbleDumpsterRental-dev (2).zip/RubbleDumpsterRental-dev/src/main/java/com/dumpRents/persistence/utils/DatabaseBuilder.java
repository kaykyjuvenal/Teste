package com.dumpRents.persistence.utils;

public class DatabaseBuilder {
}
