package com.dumpRents.persistence.utils;

public class ConnectionFactory {
}
