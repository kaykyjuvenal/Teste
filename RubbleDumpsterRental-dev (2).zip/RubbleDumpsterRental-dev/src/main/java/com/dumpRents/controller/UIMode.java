package com.dumpRents.controller;

public enum UIMode {
    VIEW,
    UPDATE,
    CREATE
}
